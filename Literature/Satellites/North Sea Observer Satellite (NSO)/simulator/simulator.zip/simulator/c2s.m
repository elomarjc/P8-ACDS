function s = c2s(x,y,z)
[s(1) s(2) s(3)] = cart2sph(x,y,z);
